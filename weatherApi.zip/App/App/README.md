# weather-app
Predict Tomorrow's coolest hour of the day 

    View tomorrow’s predicted temperatures for a given zip-code in the United States 
    so that you can know which will be the coolest hour of the day.

    The program gets data from a weather service API "https://developer.here.com"
    
    java-json.jar is used for extracting the data received from the API
    Download java-json.jar from "http://www.java2s.com/Code/Jar/j/Downloadjavajsonjar.htm"
