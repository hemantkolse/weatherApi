package com.weatherApi.Api.exception;

public class InvalidZipCodeException extends RuntimeException {

	public InvalidZipCodeException()
	{
		super("City not found, please enter a valid Zip Code");
	}
}
