package com.weatherApi.Api.exception;

public class InvalidApiFormatException extends RuntimeException{

	public InvalidApiFormatException()
	{
		super("Invalid API Format");
	}
}
