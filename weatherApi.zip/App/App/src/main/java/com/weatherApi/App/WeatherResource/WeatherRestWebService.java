package com.weatherApi.App.WeatherResource;

import java.io.IOException;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.weatherApi.Api.exception.InvalidApiFormatException;
import com.weatherApi.Api.exception.InvalidZipCodeException;
import com.weatherApi.App.Service.Weather;

@RestController
@RequestMapping("/api")
public class WeatherRestWebService {

	@Autowired
	Weather weather;
	
	// call the rest webservice (http://localhost:8080/api/getCoolestHour?zipcode=82941) by giving the zipcode
	//  as a input and you will get the tomorrows predicted coolest hour of the day
	
	
	@GetMapping(value="/getCoolestHour")
	@ResponseBody
	public String getCollestHour(@RequestParam("zipcode") String zipcode)
	{
		
		try {
			return weather.getDetails(zipcode);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//return "City not found, please enter a valid Zip Code\n";
			throw new InvalidZipCodeException();
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			// return " Invalid API format ";
			
			throw new InvalidApiFormatException();
		}
	}
	
	
	
}
